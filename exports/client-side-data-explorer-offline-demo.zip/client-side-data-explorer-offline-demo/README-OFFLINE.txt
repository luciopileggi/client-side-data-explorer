Client-Side Data Explorer - Offline Demo
========================================

This package is a static offline copy of the demo site.

How to use it:

1. Extract the ZIP archive.
2. Open index.html directly in a browser.
3. No HTTP server is required.

The dataset is embedded in offline-data.js so the browser does not need
to fetch JSON files over HTTP. Detail pages such as detail.html?id=...
work from the extracted folder because the same embedded dataset is loaded
by each page.

Configured title: Dataset records
Records: 62

Notes:

- This package is a generated artifact.
- Regenerate it with: node scripts/build-offline-package.js
- Do not use it for private, restricted, or sensitive datasets without review.
- External record links still point to online resources and require internet access.
